
												/***************Example***************
													CLASS: Contact.java
													CSC212 Data structures - Project phase II
													Fall 2023
													EDIT DATE:
													3-12-2023
													TEAM:
													team-name or number
													AUTHORS:
													Murdhi Alkaltham     443100861
													Khalid Alsalman        443101171
													Saud Albarkheel        443101765
												*************************************/
public class Contact implements Comparable<Contact> {
	private String name;
	private String phoneNumber;
	private String email;
	private String address;
	private String birthday;
	private String notes;
	public LinkedList<Event> eventsForCon;

	public Contact(String name, String phoneNumber, String email, String address, String birthday, String notes) {
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.address = address;
		this.birthday = birthday;
		this.notes = notes;
		eventsForCon = new LinkedList<Event>();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public int compareTo(Contact con) {
		return this.name.compareToIgnoreCase(con.name);
	}

	public String toString() { // contact details
		return "Contacts name: " + name + "\nContacts phone number: " + phoneNumber + "\nContacts email: " + email
				+ "\nContacts address: " + address + "\nContacts birthday: " + birthday + "\nContacts notes: " + notes
				+ "\n";
	}

}
