												/***************Example***************
													CLASS: Event.java
													CSC212 Data structures - Project phase II
													Fall 2023
													EDIT DATE:
													3-12-2023
													TEAM:
													team-name or number
													AUTHORS:
													Murdhi Alkaltham       443100861
													Khalid Alsalman        443101171
													Saud Albarkheel        443101765
												*************************************/
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;

public class Event implements Comparable<Event> {

	private boolean isEvent;
	private String title;
	private String dateTime;
	private String location;

	public LinkedList<Contact> conInEvent;
	private LocalDateTime eventDateTime; // Added LocalDateTime field
	public final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm")
			.withResolverStyle(ResolverStyle.SMART);

	public Event(boolean event, String title, String dateTime, String location) {
		this.isEvent = event;
		this.title = title;
		this.dateTime = dateTime;
		this.location = location;
		this.conInEvent = new LinkedList<Contact>();
		this.eventDateTime = parseDateTime(dateTime);
	}

	public LinkedList<Contact> getConInEvent() {
		return conInEvent;
	}

	public void setConInEvent(LinkedList<Contact> conInEvent) {
		this.conInEvent = conInEvent;
	}

	public boolean isEvent() {
		return isEvent;
	}

	public void setEvent(boolean event) {
		this.isEvent = event;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
		this.eventDateTime = parseDateTime(dateTime);
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public int compareTo(Event e) {
		return this.title.compareTo(e.getTitle());
	}

	public void display() {
		System.out.print("Event or Appointment? ");
		if (isEvent)
			System.out.println("Event");
		else
			System.out.println("Appointment");

		System.out.println("Title:" + title);
		System.out.println("Date and Time: " + formatDateTime(eventDateTime));
		System.out.println("Location:" + location);
		System.out.print("Contact name/s: ");

		if (!conInEvent.empty()) {
			conInEvent.findFirst();
			while (!conInEvent.last()) {
				System.out.print(conInEvent.retrieve().getName() + ", ");
				conInEvent.findNext();
			}
			System.out.println(conInEvent.retrieve().getName() + ".");
			System.out.println();
		} else
			System.out.println("no contacts in this event");
	}

	private LocalDateTime parseDateTime(String dateTime) {
		return LocalDateTime.parse(dateTime, formatter); //
	}

	private String formatDateTime(LocalDateTime dateTime) {
		return dateTime.format(formatter);
	}
}

class Node<T> {

	Node next;
	T data;

	public Node() {
		data = null;
		next = null;
	}

	public Node(T d) {
		this.data = d;
		next = null;
	}

}

class LinkedList<T> {

	private Node<T> head;
	private Node<T> current;

	public LinkedList() {
		current = head = null;
	}

	public boolean empty() {
		return (head == null);
	}

	public boolean full() {
		return false;
	}

	public boolean last() {
		return current.next == null;
	}

	public void findFirst() {
		current = head;
	}

	public void findNext() {
		current = current.next;
	}

	public T retrieve() {
		return current.data;
	}

	public void update(T val) {
		current.data = val;
	}

	public void insert(T val) {
		Node<T> tmp = new Node<T>();

		if (empty()) {
			current = head = new Node<T>(val);
		} else {
			tmp = current.next;
			current.next = new Node<T>(val);
			current = current.next;
			current.next = tmp;
		}
	}

	public void remove() {
		if (current == head)
			head = head.next;
		else {
			Node<T> tmp = head;
			while (tmp.next != current)
				tmp = tmp.next;

			tmp.next = current.next;
		}

		if (current.next == null)
			current = head;
		else
			current = current.next;
	}

}
