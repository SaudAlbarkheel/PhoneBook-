												/***************Example***************
													CLASS: PhoneBook.java
													CSC212 Data structures - Project phase II
													Fall 2023
													EDIT DATE:
													3-12-2023
													TEAM:
													team-name or number
													AUTHORS:
													Murdhi Alkaltham       443100861
													Khalid Alsalman        443101171
													Saud Albarkheel        443101765
												*************************************/
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class PhoneBook {

	Scanner scanner = new Scanner(System.in);
	public BST<Contact> contacts;
	public LinkedList<Event> allEvents;

	public PhoneBook() {
		contacts = new BST<>();
		allEvents = new LinkedList<Event>();
	}

	public void addContactToPhoneBook() {
		System.out.print("Enter contact name: ");
		String name = scanner.nextLine();

		System.out.print("Enter contact phone number: ");
		String phoneNumber = scanner.nextLine();

		System.out.print("Enter contact email: ");
		String email = scanner.nextLine();

		System.out.print("Enter contact address: ");
		String address = scanner.nextLine();

		System.out.print("Enter contact birthday: ");
		String birthday = scanner.nextLine();

		System.out.print("Enter contact notes: ");
		String notes = scanner.nextLine();

		Contact newContact = new Contact(name, phoneNumber, email, address, birthday, notes);
		addContact(newContact);
	}

	public void addContact(Contact con) { // checks if contact or phone exist. if not Contact added.

		if (contacts.phoneExist(con.getPhoneNumber()))
			System.out.println("Contact with this Phone number already exists");
		else {
			boolean name = contacts.insert(con.getName(), con);
			if (name)
				System.out.println("Contact added to the phonebook");
			else
				System.out.println("Contact with this name already exists");
		}
	}

	public void search() {

		System.out.println("Enter search criteria:");
		System.out.println("1. Name");
		System.out.println("2. Phone Number");
		System.out.println("3. Email Address");
		System.out.println("4. Address");
		System.out.println("5. Birthday");

		int pick = scanner.nextInt();
		scanner.nextLine();

		switch (pick) {

		case 1:
			System.out.println("name"); // here the name has a different algo since its the key so found easily.
			boolean found = contacts.findKey(scanner.nextLine());
			if (found)
				System.out.println(contacts.retrieve().toString());
			else
				System.out.println("Not found");
			break;
		case 2:
			System.out.println("num");
			contacts.searchPhoneNumber(scanner.nextLine());
			break;
		case 3:
			System.out.println("Enter email address you want to search for");
			contacts.searchEmail(scanner.nextLine());
			break;
		case 4:
			System.out.println("Enter address you want to search for");
			contacts.searchAddress(scanner.nextLine());
			break;
		case 5:
			System.out.println("Enter birthday you want to search for");
			contacts.searchBirthday(scanner.nextLine());
			break;
		default:
			System.out.println("Please only enter the numbers that are displayed");

		}

	}

	public void deleteContact() {
		System.out.println("Enter contact name to delete");
		String name = scanner.nextLine();
		boolean flag = contacts.removeKey(name);

		if (!flag) {
			System.out.println("Contact not found");
			return;
		}
		System.out.println("Contact " + name + " has been deleted ");
		if (!allEvents.empty()) {
			allEvents.findFirst();
			while (!allEvents.last()) {
				allEvents.retrieve().conInEvent.findFirst();

				while (!allEvents.retrieve().conInEvent.last()) {
					if (allEvents.retrieve().conInEvent.retrieve().getName().equals(name)) {
						allEvents.retrieve().conInEvent.remove(); // checking if allEvent still has event with deleted
																	// contact. if exist remove contact from event.
					} else
						allEvents.retrieve().conInEvent.findNext();

				}
				if (allEvents.retrieve().conInEvent.retrieve().getName().equals(name))
					allEvents.retrieve().conInEvent.remove();

				if (allEvents.retrieve().conInEvent.empty())
					allEvents.remove();
				else
					allEvents.findNext();

			} // last allEvents iteration
			allEvents.retrieve().conInEvent.findFirst();
			while (!allEvents.retrieve().conInEvent.last()) {
				if (allEvents.retrieve().conInEvent.retrieve().getName().equals(name)) {
					allEvents.retrieve().conInEvent.remove();
				} else
					allEvents.retrieve().conInEvent.findNext();
			}
			if (allEvents.retrieve().conInEvent.retrieve().getName().equals(name))
				allEvents.retrieve().conInEvent.remove();

			if (allEvents.retrieve().conInEvent.empty())
				allEvents.remove();

		}

	}

	public void print() {
		if (!contacts.empty()) {
			contacts.inOrder();
		} else
			System.out.println("No contacts in the phone book");
	}

	public void printAllEvents() {
		if (!allEvents.empty()) {
			allEvents.findFirst();
			while (!allEvents.last()) {
				allEvents.retrieve().display();
				System.out.println();
				allEvents.findNext();
			}
			allEvents.retrieve().display();
		} else
			System.out.println("Currently no Events.");
	}

	public void searchEvent() {

		System.out.println("Enter search criteria ");
		System.out.println("1.Contact name ");
		System.out.println("2.Event title");

		int critChoice = scanner.nextInt();
		scanner.nextLine();
		switch (critChoice) {
		case 1:
			System.out.println("Enter the contacts name: ");
			String name = scanner.nextLine();
			boolean found = contacts.findKey(name);
			if (found) {
				printContactEvents(contacts.retrieve().eventsForCon);
			} else
				System.out.println("This contact doesnt exist\n");
			break;

		case 2:
			System.out.println("Enter the event title:");
			String title = scanner.nextLine();
			boolean flag = false;
			if (!allEvents.empty()) {
				allEvents.findFirst();
				while (!allEvents.last()) {
					if (allEvents.retrieve().getTitle().equalsIgnoreCase(title)) {
						allEvents.retrieve().display();
						flag = true;
					}
					allEvents.findNext();
				}
				if (allEvents.retrieve().getTitle().equalsIgnoreCase(title)) {
					allEvents.retrieve().display();
					flag = true;
				}
			}
			if (flag == false) {
				System.out.println("No events found with that title");
			}
			break;
		default:
			System.out.println("Pick 1 or 2");
		}
	}

	public void printContactEvents(LinkedList<Event> l) {
		if (!l.empty()) {
			l.findFirst();
			while (!l.last()) {
				l.retrieve().display();
				l.findNext();
			}
			l.retrieve().display();
		} else
			System.out.println("This contacts currently has no events");
	}

	public void sortEvent(Event e) {
		if (!allEvents.empty()) {
			allEvents.findFirst();
			while (!allEvents.last()) {
				if (e.getTitle().compareToIgnoreCase(allEvents.retrieve().getTitle()) <= -1) {
					Event tmp = allEvents.retrieve();
					allEvents.update(e);
					allEvents.insert(tmp);
					return;
				}
				allEvents.findNext();
			}
			if (e.getTitle().compareToIgnoreCase(allEvents.retrieve().getTitle()) <= -1) {
				Event tmp = allEvents.retrieve();
				allEvents.update(e);
				allEvents.insert(tmp);
			} else {
				allEvents.insert(e);
			}
		} else
			allEvents.insert(e);
	}

	public void printContactsByFirstName() {
		System.out.println("Enter the first name of the contact:");
		String firstName = scanner.nextLine();
		contacts.printContactsByFirstName(firstName);
	}

	public void scheduleEvent(int n) {
		boolean isEvent = (n == 1);

		System.out.println("Enter the event title: ");
		String title = scanner.nextLine();

		System.out.println("Enter event date and time (MM/DD/YYYY HH:MM): ");
		String dateAndTime = scanner.nextLine();

		System.out.println("Enter the event location: ");
		String location = scanner.nextLine();

		// Check for conflicts before scheduling the event
		Event newEvent = new Event(isEvent, title, dateAndTime, location);
		if (isEvent) {
			System.out.println("Enter contacts names separated by a comma: ");
			String[] contactNames = scanner.nextLine().split(","); // apply all names after "," in array
			for (String contactName : contactNames) { // iterate through the array
				Contact contact = contacts.searchName(contactName.trim()); // check if name exist in the BST
				if (contact != null) {
					if (eventsConflict(newEvent, contact.eventsForCon)) {
						// if conflict do not schedule
						System.out.println("Event not scheduled due to conflict.");
						return;
					}
					newEvent.conInEvent.insert(contact);
					contact.eventsForCon.insert(newEvent);
				} else {
					System.out.println("Contact '" + contactName.trim() + "' not found.");
					return;
				}
			}
		} else {
			System.out.println("Enter contact name: ");
			String contactName = scanner.nextLine();
			Contact contact = contacts.searchName(contactName);
			if (contact != null) {

				if (eventsConflict(newEvent, contact.eventsForCon)) {
					// if there is conflict do not schedule
					System.out.println("Event not scheduled due to conflict.");
					return;
				}
				newEvent.conInEvent.insert(contact);
				contact.eventsForCon.insert(newEvent);
			} else {
				System.out.println("Contact '" + contactName + "' not found.");
				return;
			}
		}

		sortEvent(newEvent);
		System.out.println("Event scheduled successfully!");
	}

	private boolean eventsConflict(Event newEvent, LinkedList<Event> existingEvents) {
		if (!existingEvents.empty()) {
			existingEvents.findFirst();
			while (!existingEvents.last()) {
				Event existingEvent = existingEvents.retrieve();
				// Compare date and time for conflicts
				if (eventsConflict(newEvent, existingEvent)) {
					return true; // Conflict detected
				}
				existingEvents.findNext();
			}
			// Check the last event in the list
			return eventsConflict(newEvent, existingEvents.retrieve());
		}
		return false; // empty events meaning no possible conflict
	}

	// check for conflict between new event and events a contact has.
	private boolean eventsConflict(Event newEvent, Event oldEvent) {
		// Parse date and time strings to LocalDateTime for comparison
		LocalDateTime dAndT1 = parseDateTime(newEvent.getDateTime());
		LocalDateTime dAndT2 = parseDateTime(oldEvent.getDateTime());

		// Check if events are at the same time
		return dAndT1.equals(dAndT2);
	}

	// parse date and time strings to LocalDateTime (mm/dd/yyyy hh:mm)
	private LocalDateTime parseDateTime(String dateTime) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm");
		try {
			return LocalDateTime.parse(dateTime, formatter);
		} catch (Exception e) {
			System.out
					.println("An error occurred while parsing date and time. Please add date and time as instructed.");
			System.out.println("Error: " + e.getMessage());
			return null;
		}
	}

}
