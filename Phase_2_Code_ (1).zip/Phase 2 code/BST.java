												/***************Example***************
													CLASS: BST.java
													CSC212 Data structures - Project phase II
													Fall 2023
													EDIT DATE:
													3-12-2023
													TEAM:
													team-name or number
													AUTHORS:
													Murdhi Alkaltham       443100861
													Khalid Alsalman        443101171
													Saud Albarkheel        443101765
												*************************************/
class BSTNode<T> {

	public String key;
	public T data;
	public BSTNode<T> left, right;

	public BSTNode(String k, T d) {
		key = k;
		data = d;
		left = right = null;
	}

}

public class BST<T> {

	private BSTNode<T> root, current;

	public BST() {
		root = current = null;
	}

	public boolean empty() {
		return root == null;
	}

	public boolean full() {
		return false;
	}

	public T retrieve() {
		return current.data;
	}

	public void update(T d) {
		current.data = d;
	}

	public void inOrder() {
		inOrder(root);
	}

	private void inOrder(BSTNode<T> p) {
		if (p != null) {
			inOrder(p.left);
			System.out.println(((Contact) p.data).toString());
			inOrder(p.right);
		}
	}

	public boolean findKey(String k) {
		BSTNode<T> p = root;
		BSTNode<T> q = root;

		while (p != null) {
			q = p;
			if (k.compareToIgnoreCase(p.key) == 0) {
				current = p;
				return true;
			} else if (k.compareToIgnoreCase(p.key) > 0)
				p = p.right;
			else
				p = p.left;
		}
		current = q;
		return false;
	}

	public boolean insert(String k, T e) {
		BSTNode<T> p = root;
		BSTNode<T> q = root;

		while (p != null) {
			q = p;
			if (k.compareToIgnoreCase(p.key) == 0)
				return false;
			else if (k.compareToIgnoreCase(p.key) > 0)
				p = p.right;
			else
				p = p.left;
		}
		if (q == null) {
			root = new BSTNode<T>(k, e);
			current = root;
		} else {

			if (k.compareToIgnoreCase(q.key) > 0) {
				q.right = new BSTNode<T>(k, e);
				current = q.right;
			} else {
				q.left = new BSTNode<T>(k, e);
				current = q.left;
			}
		}
		return true;
	}

	public boolean removeKey(String k) {

		String k1 = k;
		BSTNode<T> p = root;
		BSTNode<T> q = null;

		while (p != null) {

			if (k.compareToIgnoreCase(p.key) < 0) {
				q = p;
				p = p.left;
			} else if (k.compareToIgnoreCase(p.key) > 0) {
				q = p;
				p = p.right;
			} else {

				if (p.left != null && p.right != null) {
					BSTNode<T> min = p.right;
					q = p;
					while (min.left != null) {
						q = min;
						min = min.left;
					}
					p.key = min.key;
					p.data = min.data;
					k1 = min.key;
					p = min;
				}

				if (p.left != null)
					p = p.left;
				else
					p = p.right;

				if (q == null)
					root = p;
				else {
					if (k1.compareToIgnoreCase(q.key) < 0)
						q.left = p;
					else
						q.right = p;
				}
				current = root;
				return true;
			}

		}
		return false;
	}

	public boolean phoneExist(String e) {
		return phoneExist(root, e);
	}

	private boolean phoneExist(BSTNode<T> p, String e) {

		if (p == null)
			return false;

		if (((Contact) p.data).getPhoneNumber().equalsIgnoreCase(e))
			return true;
		return phoneExist(p.left, e) || phoneExist(p.right, e);
	}

	public void searchPhoneNumber(String e) {
		Contact c = searchPhoneNumber(root, e);
		if (c == null) {
			System.out.println("No contacts with that phone");
		} else {
			System.out.println(c.toString());
		}
	}

	private Contact searchPhoneNumber(BSTNode<T> p, String e) {
		if (p == null)
			return null;

		if (((Contact) p.data).getPhoneNumber().equalsIgnoreCase(e))
			return (Contact) p.data;

		Contact left = searchPhoneNumber(p.left, e);
		if (left != null)
			return left;

		return searchPhoneNumber(p.right, e);
	}

	public void searchEmail(String e) {
		if (!searchEmail(root, e)) {
			System.out.println("No contacts found with that address");
		}
	}

	private boolean searchEmail(BSTNode<T> p, String e) {
		if (p == null) {
			return false;
		}

		boolean Left = searchEmail(p.left, e);
		boolean Right = searchEmail(p.right, e);

		if (((Contact) p.data).getEmail().equalsIgnoreCase(e)) {
			System.out.println(((Contact) p.data).toString());
			return true;
		}

		return Left || Right;
	}

	public void searchAddress(String e) {

		if (!searchAddress(root, e)) {
			System.out.println("No contacts found with that address");
		}
	}

	private boolean searchAddress(BSTNode<T> p, String e) {
		if (p == null) {
			return false;
		}

		boolean Left = searchAddress(p.left, e);
		boolean Right = searchAddress(p.right, e);

		if (((Contact) p.data).getAddress().equalsIgnoreCase(e)) {
			System.out.println(((Contact) p.data).toString());
			return true;
		}

		return Left || Right;
	}

	public void searchBirthday(String e) {

		if (!searchBirthday(root, e)) {
			System.out.println("No contacts found with that address");
		}
	}

	private boolean searchBirthday(BSTNode<T> p, String e) { // iterates through the whole BST to find birthday
		if (p == null) {
			return false;
		}

		boolean Left = searchBirthday(p.left, e);
		boolean Right = searchBirthday(p.right, e);

		if (((Contact) p.data).getBirthday().equalsIgnoreCase(e)) {
			System.out.println(((Contact) p.data).toString());
			return true;
		}

		return Left || Right;
	}

	public Contact searchName(String e) {
		Contact c = searchName(root, e);
		if (c == null) {
			return null;
		} else {
			return c;
		}
	}

	private Contact searchName(BSTNode<T> p, String e) {
		if (p == null)
			return null;

		if (((Contact) p.data).getName().equalsIgnoreCase(e))
			return (Contact) p.data;

		Contact left = searchName(p.left, e);
		if (left != null)
			return left;

		return searchName(p.right, e);
	}

	public void printContactsByFirstName(String firstName) {
		printContactsByFirstName(root, firstName);
	}

	private void printContactsByFirstName(BSTNode<T> p, String firstName) {
		if (p == null) {
			return;
		}

		printContactsByFirstName(p.left, firstName);

		Contact contact = (Contact) p.data;
		String contactFirstName = contact.getName().split(" ")[0]; // Get the first word

		if (contactFirstName.equalsIgnoreCase(firstName)) {
			System.out.println(contact.toString());
		}

		printContactsByFirstName(p.right, firstName);
	}

}
