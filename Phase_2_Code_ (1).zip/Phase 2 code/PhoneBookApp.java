												/***************Example***************
													CLASS: PhoneBookApp.java
													CSC212 Data structures - Project phase II
													Fall 2023
													EDIT DATE:
													3-12-2023
													TEAM:
													team-name or number
													AUTHORS:
													Murdhi Alkaltham       443100861
													Khalid Alsalman        443101171
													Saud Albarkheel        443101765
												*************************************/
import java.util.Scanner;
import java.util.*;

public class PhoneBookApp {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		PhoneBook p1 = new PhoneBook();

		int choice = 0;
		do {
			try {
				System.out.println("Welcome to the Linked List Phonebook! Please choose an option:");
				System.out.println("1. Add a contact");
				System.out.println("2. Search for a contact");
				System.out.println("3. Delete a contact");
				System.out.println("4. Schedule an event"); //
				System.out.println("5. Print event details");
				System.out.println("6. Print contacts by first name");
				System.out.println("7. Print all events alphabetically");
				System.out.println("8. Exit");
				System.out.print("Enter your choice: \n");

				choice = scanner.nextInt();
				scanner.nextLine();

				System.out.println();

				switch (choice) {

				case 1:
					p1.addContactToPhoneBook();
					System.out.println();
					break;
				case 2:
					p1.search();
					System.out.println();
					break;
				case 3:
					p1.deleteContact();
					System.out.println();
					break;
				case 4:
					System.out.println("Enter 1 or 2");
					System.out.println("1-Event");
					System.out.println("2-appointment");
					int c = scanner.nextInt();
					scanner.nextLine();
					if (c == 1 || c == 2)
						p1.scheduleEvent(c);
					else
						System.out.println("Invalid, Choices are only 1 or 2");
					System.out.println();
					break;
				case 5:
					p1.searchEvent();
					System.out.println();
					break;
				case 6:
					p1.printContactsByFirstName();
					System.out.println();
					break;
				case 7:
					p1.printAllEvents();
					System.out.println();
					break;
				case 8:
					System.out.println("Goodbye!");
					break;

				default:
					System.out.println();
					System.out.println("Invalid choice! Please select a valid option.");
				}
			} catch (InputMismatchException e) {
				System.out.println("Invalid input please follow instructions.\n");
				scanner.nextLine();
				System.out.println();
			} catch (Exception e) {
				System.out.println("An error occured please follow the instructions. \nError: " + e.getMessage());
				System.out.println();
			}

		} while (choice != 8);

	}

}